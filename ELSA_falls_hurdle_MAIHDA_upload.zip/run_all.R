# Runs the full ELSA falls analysis in order. From the repository root:
#   Rscript run_all.R
# Each script can also be run on its own once its predecessors have completed.
scripts <- sort(list.files("scripts", pattern = "^[0-9]{2}_.*\\.R$", full.names = TRUE))
for (s in scripts) {
  cat("\n==== ", s, " ====\n", sep = "")
  start <- Sys.time()
  status <- system2(file.path(R.home("bin"), "Rscript"), c("--vanilla", shQuote(s)))
  if (status != 0) stop("Failed: ", s)
  cat("Finished in", format(round(difftime(Sys.time(), start, units = "mins"), 1)), "\n")
}
cat("\nAll scripts completed.\n")

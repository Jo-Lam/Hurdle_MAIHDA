# Additive-only (no stratum random intercept) models and within-MAIHDA stratum departures.

# Fits main-effects-only versions of the requested components and returns predictions for `grid`.
# Fits are stored as "additive_<component>" so predict_distribution(..., spec = "additive") can be reused.
fit_fixed <- function(dat, w, grid, components = c("poisson", "nb2", "occurrence", "positive")) {
  d <- compress_data(dat, w)
  fits <- list()
  diags <- list()
  for (comp in components) {
    z <- if (comp == "positive") d[d$y > 0, ] else d
    fml <- as.formula(paste(if (comp == "occurrence") "positive" else "y", "~ sex + age_group + education + wealth_group"))
    fam <- switch(comp, poisson = poisson(), nb2 = glmmTMB::nbinom2(), occurrence = binomial(),
                  positive = glmmTMB::truncated_nbinom2())
    warnings <- character()
    attempt <- function(retry = FALSE) {
      control <- if (retry) {
        glmmTMB::glmmTMBControl(optimizer = optim, optArgs = list(method = "BFGS"), optCtrl = list(maxit = 2000))
      } else {
        glmmTMB::glmmTMBControl(optCtrl = list(iter.max = 2000, eval.max = 3000, rel.tol = 1e-10))
      }
      tryCatch(withCallingHandlers(
        glmmTMB::glmmTMB(fml, data = z, weights = fit_weight, family = fam, control = control),
        warning = function(e) {
          warnings <<- c(warnings, conditionMessage(e))
          invokeRestart("muffleWarning")
        }), error = function(e) e)
    }
    good <- function(f) !inherits(f, "error") && f$fit$convergence == 0 && isTRUE(f$sdr$pdHess)
    f <- attempt()
    retried <- FALSE
    if (!good(f)) {
      a <- attempt(TRUE)
      retried <- TRUE
      if (good(a) || inherits(f, "error")) f <- a
    }
    stopifnot(!inherits(f, "error"))
    fits[[paste0("additive_", comp)]] <- f
    diags[[comp]] <- data.frame(
      component = comp, good = good(f), convergence = f$fit$convergence, hessian = isTRUE(f$sdr$pdHess),
      dispersion = if (comp %in% c("nb2", "positive")) sigma(f) else NA,
      gradient = max(abs(f$obj$gr(f$fit$par))), retried = retried,
      warnings = paste(unique(warnings), collapse = " | "))
  }
  models <- if (all(c("poisson", "nb2") %in% components)) c("Poisson", "NB2", "Hurdle NB2") else "Hurdle NB2"
  pred <- do.call(rbind, lapply(models, function(model) {
    cbind(grid[, 1:5], model = model, predict_distribution(fits, grid, "additive", model))
  }))
  list(fits = fits, diagnostics = do.call(rbind, diags), predictions = pred)
}

# Predictions from a fitted MAIHDA model with every stratum random effect set to zero,
# holding the fitted fixed effects and shape. MAIHDA prediction / this prediction isolates
# the stratum departure ("interaction") without refitting.
zero_re_prediction <- function(fits, grid, model) {
  g <- grid
  g$fit_weight <- 1
  link <- function(comp) as.numeric(predict(fits[[paste0("additive_", comp)]], newdata = g, type = "link", re.form = NA))
  if (model == "Poisson") {
    mu <- exp(link("poisson"))
    prob <- -expm1(-mu)
    mp <- mu / prob
  } else {
    comp <- if (model == "NB2") "nb2" else "positive"
    mu <- exp(link(comp))
    shape <- sigma(fits[[paste0("additive_", comp)]])
    mass <- -expm1(-shape * log1p(mu / shape))
    mp <- mu / mass
    prob <- if (model == "NB2") mass else plogis(link("occurrence"))
  }
  data.frame(p = prob, m_plus = mp, total_mean = prob * mp)
}

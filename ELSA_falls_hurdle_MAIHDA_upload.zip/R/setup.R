# Shared paths and functions. Every script sources this file; run scripts from the repository root.
root <- normalizePath(".", winslash = "/")
if (!file.exists(file.path(root, "R", "falls_functions.R"))) stop("Run the scripts from the repository root.")

# UK Data Service ELSA Stata ZIP (SN 5050): not in the repository. Put it in data/ or set ELSA_DATA_DIR.
data_dir <- Sys.getenv("ELSA_DATA_DIR", file.path(root, "data"))
private_dir <- file.path(root, "private")                # participant-level caches and fitted models: never share
out_main <- file.path(root, "outputs", "main")           # main fits, validation, bootstrap and sensitivity analyses
out_contrasts <- file.path(root, "outputs", "contrasts") # additive versus MAIHDA comparisons and figures
out_supp <- file.path(root, "outputs", "supplementary_data")  # D9-D11 with small cells suppressed
for (d in c(private_dir, out_main, out_contrasts, out_supp)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

source(file.path(root, "R", "falls_functions.R"))
source(file.path(root, "R", "contrast_functions.R"))

read_out <- function(dir, name) read.csv(file.path(dir, paste0(name, ".csv")), stringsAsFactors = FALSE)
SEED <- 20261010L
N_BOOT <- 200L
N_FOLDS <- 5L

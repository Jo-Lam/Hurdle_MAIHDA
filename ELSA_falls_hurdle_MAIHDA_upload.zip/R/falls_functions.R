# Wave 10 falls: data preparation, model fitting, coherent predictions and scoring.
#
# Estimands for each stratum j:
#   p_j         probability of any fall (occurrence)
#   m_plus_j    mean number of falls among fallers (frequency; includes the first fall)
#   total_mean  p_j * m_plus_j, the overall mean
# Every model's predictions are derived from its own fitted count distribution.

required <- c("haven", "glmmTMB", "ggplot2", "digest", "tidyselect")
stopifnot(all(vapply(required, requireNamespace, logical(1), quietly = TRUE)))

num <- function(x) as.numeric(x)

write_table <- function(x, name, out) {
  utils::write.csv(x, file.path(out, paste0(name, ".csv")), row.names = FALSE, na = "")
}

weighted_quantile <- function(x, w, p) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  x <- x[ok]
  w <- w[ok]
  o <- order(x)
  x <- x[o]
  w <- w[o]
  cw <- cumsum(w) / sum(w)
  vapply(p, function(z) x[which(cw >= z)[1L]], numeric(1))
}

# ---------------------------------------------------------------------------
# Data preparation
# ---------------------------------------------------------------------------

# Reads the UK Data Service ELSA Stata archive (SN 5050) found in data_dir, extracts only the
# required files to a temporary folder (deleted on exit), builds the analytic sample and writes
# aggregate audit tables to `out`. Returns participant-level data for local use only.
load_falls <- function(data_dir, out) {
  archive <- list.files(data_dir, pattern = "\\.zip$", full.names = TRUE)
  if (length(archive) != 1L) {
    stop("Place exactly one ELSA Stata ZIP from the UK Data Service (SN 5050) in ", data_dir)
  }
  inv <- unzip(archive, list = TRUE)
  patterns <- c(
    core = "/wave_10_elsa_data_eul_v4\\.dta$",
    ifs = "/wave_10_ifs_derived_variables\\.dta$",
    financial = "/wave_10_financial_derived_variables\\.dta$",
    previous = "/wave_9_elsa_data.*\\.dta$"
  )
  members <- vapply(patterns, function(p) {
    v <- grep(p, inv$Name, value = TRUE)
    stopifnot(length(v) == 1L)
    v
  }, character(1))
  scratch <- tempfile("elsa_falls_")
  dir.create(scratch)
  on.exit(unlink(scratch, recursive = TRUE), add = TRUE)
  unzip(archive, files = members, exdir = scratch)

  core_vars <- c("idauniq", "idahhw10", "corepartner", "cohort", "wavejoined", "askpx", "askinst",
                 "indager", "indsex", "hefla", "heflb", "w10xwgt", "iintdatm", "iintdaty")
  core <- haven::read_dta(file.path(scratch, members["core"]), col_select = tidyselect::all_of(core_vars))
  ifs <- haven::read_dta(file.path(scratch, members["ifs"]), col_select = c("idauniq", "edqual"))
  financial <- haven::read_dta(file.path(scratch, members["financial"]),
                               col_select = c("idauniq", "nettotw_bu_s", "nettotw_bu_f", "nettotw_bu_t", "nettotw_bu_ni2"))
  previous <- haven::read_dta(file.path(scratch, members["previous"]),
                              col_select = c("idauniq", "iintdatm", "iintdaty", "askpx"))
  for (z in list(core, ifs, financial, previous)) stopifnot(!anyNA(z$idauniq), !anyDuplicated(z$idauniq))
  stopifnot(setequal(core$idauniq, ifs$idauniq), setequal(core$idauniq, financial$idauniq))

  all <- as.data.frame(lapply(core, num))
  j <- match(all$idauniq, ifs$idauniq)
  all$education_code <- num(ifs$edqual[j])
  j <- match(all$idauniq, financial$idauniq)
  all$wealth <- num(financial$nettotw_bu_s[j])
  all$wealth_valid <- num(financial$nettotw_bu_f[j]) == 0  # flag 0 validates the value, including negative wealth
  all$wealth_imputation_type <- num(financial$nettotw_bu_t[j])
  all$wealth_imputed_components <- num(financial$nettotw_bu_ni2[j])
  j <- match(all$idauniq, previous$idauniq)
  all$previous_month <- num(previous$iintdatm[j])
  all$previous_year <- num(previous$iintdaty[j])
  all$previous_proxy <- num(previous$askpx[j])

  # Social characteristics. Age -7 denotes top-coded 90+, retained in the 80+ group.
  all$age_topcoded <- all$indager == -7
  all$age_group <- factor(
    ifelse(all$age_topcoded | all$indager >= 80, "80+",
           ifelse(all$indager >= 70, "70-79", ifelse(all$indager >= 60, "60-69", NA))),
    levels = c("60-69", "70-79", "80+"))
  all$sex <- factor(ifelse(all$indsex == 1, "Male", ifelse(all$indsex == 2, "Female", NA)),
                    levels = c("Male", "Female"))
  # edqual: 1 degree/equivalent; 2-6 other qualifications (including foreign/other); 7 none.
  all$education <- factor(
    ifelse(all$education_code == 7, "No qualifications",
           ifelse(all$education_code == 1, "Degree/equivalent",
                  ifelse(all$education_code %in% 2:6, "Other qualifications", NA))),
    levels = c("No qualifications", "Other qualifications", "Degree/equivalent"))

  # Outcome: zero only for an explicit 'no fall' with the count skipped by routing;
  # a positive integer count (1-400) for 'yes'. Everything else stays missing.
  all$y <- NA_real_
  all$y[all$hefla == 2 & all$heflb == -1] <- 0
  ok <- all$hefla == 1 & all$heflb >= 1 & all$heflb <= 400 & all$heflb == round(all$heflb)
  all$y[ok] <- all$heflb[ok]

  # Sequential restrictions, recorded for the sample-flow table.
  stage <- list()
  current <- rep(TRUE, nrow(all))
  add_stage <- function(label, keep) {
    current <<- current & !is.na(keep) & keep
    stage[[length(stage) + 1L]] <<- data.frame(
      stage = label, n = sum(current), positive = sum(all$y[current] > 0, na.rm = TRUE),
      outcome_missing = sum(is.na(all$y[current])))
  }
  add_stage("All wave 10 core-file rows", current)
  add_stage("Core members", all$corepartner == 1)
  add_stage("Private-household interviews", all$askinst == 0)
  add_stage("Age 60+ including top-coded 90+", !is.na(all$age_group))
  add_stage("Positive cross-sectional weight", is.finite(all$w10xwgt) & all$w10xwgt > 0)

  # Wealth tertiles: weighted cut-points in the eligible 60+ target population,
  # before exclusions for missing falls or education.
  target <- all[current, ]
  wvalid <- target$wealth_valid & is.finite(target$wealth)
  cuts <- weighted_quantile(target$wealth[wvalid], target$w10xwgt[wvalid], c(1 / 3, 2 / 3))
  stopifnot(length(unique(cuts)) == 2L)
  all$wealth_group <- factor(
    ifelse(all$wealth_valid & is.finite(all$wealth),
           ifelse(all$wealth <= cuts[1], "Lower", ifelse(all$wealth <= cuts[2], "Middle", "Higher")), NA),
    levels = c("Lower", "Middle", "Higher"))

  add_stage("Personal interviews: falls not collected from proxies", all$askpx == 0)
  eligible <- all[current, ]
  add_stage("Observed coherent fall outcome", is.finite(all$y))
  add_stage("Known sex and harmonised education", !is.na(all$sex) & !is.na(all$education))
  add_stage("Validated derived benefit-unit wealth", !is.na(all$wealth_group))

  dat <- all[current, ]
  stopifnot(nrow(dat) > 0, !anyNA(dat$idahhw10), all(dat$idahhw10 > 0))
  dat$positive <- as.integer(dat$y > 0)
  dat$stratum <- interaction(dat$sex, dat$age_group, dat$education, dat$wealth_group, sep = " | ", drop = FALSE)
  dat$weight <- dat$w10xwgt / mean(dat$w10xwgt)
  dat$duration_years <- ((dat$iintdaty - dat$previous_year) * 12 + dat$iintdatm - dat$previous_month) / 12
  dat$duration_known <- is.finite(dat$duration_years) & dat$duration_years > 0 & dat$previous_proxy == 0
  dat$recall_group <- factor(ifelse(dat$cohort == 10, "New cohort 10",
                                    ifelse(dat$duration_known, "Wave 9 personal interview",
                                           "Other/unknown previous interview")))

  # Prediction grid: all 54 strata, including any without observations.
  grid <- expand.grid(sex = levels(dat$sex), age_group = levels(dat$age_group),
                      education = levels(dat$education), wealth_group = levels(dat$wealth_group),
                      stringsAsFactors = FALSE)
  for (v in c("sex", "age_group", "education", "wealth_group")) grid[[v]] <- factor(grid[[v]], levels = levels(dat[[v]]))
  grid$stratum <- interaction(grid$sex, grid$age_group, grid$education, grid$wealth_group, sep = " | ", drop = FALSE)
  grid$log_duration <- 0

  eligible_stratum <- as.character(interaction(eligible$sex, eligible$age_group, eligible$education,
                                               eligible$wealth_group, sep = " | ", drop = FALSE))
  eligible_complete <- !is.na(eligible$sex) & !is.na(eligible$education) & !is.na(eligible$wealth_group)
  strata <- do.call(rbind, lapply(seq_len(nrow(grid)), function(i) {
    z <- dat[dat$stratum == grid$stratum[i], ]
    e <- eligible[eligible_complete & eligible_stratum == as.character(grid$stratum[i]), ]
    has <- nrow(z) > 0
    pos <- z$positive == 1
    data.frame(
      grid[i, 1:5], n_eligible = nrow(e), n = nrow(z), n_households = length(unique(z$idahhw10)),
      n_positive = sum(z$positive), n_recurrent = sum(z$y >= 2), events = sum(z$y), sum_weight = sum(z$w10xwgt),
      effective_n = if (has) sum(z$w10xwgt)^2 / sum(z$w10xwgt^2) else 0,
      observed_p = if (has) mean(z$positive) else NA,
      weighted_p = if (has) weighted.mean(z$positive, z$w10xwgt) else NA,
      observed_positive_mean = if (any(pos)) mean(z$y[pos]) else NA,
      weighted_positive_mean = if (any(pos)) weighted.mean(z$y[pos], z$w10xwgt[pos]) else NA,
      weighted_mean = if (has) weighted.mean(z$y, z$w10xwgt) else NA)
  }))

  # Aggregate audit tables (contain small cells: review before sharing).
  write_table(do.call(rbind, stage), "sample_flow", out)
  write_table(data.frame(
    variable = c("idauniq", "corepartner", "askpx", "askinst", "indager", "indsex", "hefla/heflb", "w10xwgt",
                 "edqual", "nettotw_bu_s", "nettotw_bu_f", "nettotw_bu_ni2", "iintdatm/iintdaty"),
    definition = c("One-to-one joins; no IDs exported", "Core member=1", "Personal=0; proxy=1", "Private household=0",
                   "60+; -7 retained as 90+", "Recorded sex 1 Male, 2 Female",
                   "No and skipped count =>0; Yes and positive integer 1..400 =>count",
                   "Main interview cross-sectional weight; positive only",
                   "1 Degree/equivalent; 2:6 Other qualifications; 7 None",
                   "Benefit-unit net non-pension wealth, not whole-household wealth",
                   "0 validates values, including genuine negative wealth",
                   "Number of imputed component values; conditional inference on supplied imputations",
                   "Month-resolution interview interval for W9 sensitivity")),
    "variable_dictionary", out)
  write_table(data.frame(probability = c(1 / 3, 2 / 3), wealth_cut = cuts, target_n = nrow(target),
                         valid_wealth_n = sum(wvalid)), "wealth_thresholds", out)
  write_table(strata, "stratum_information", out)
  miss <- do.call(rbind, lapply(c("sex", "age_group", "education", "wealth_group"), function(v) {
    do.call(rbind, lapply(levels(eligible[[v]]), function(level) {
      z <- eligible[!is.na(eligible[[v]]) & eligible[[v]] == level, ]
      data.frame(dimension = v, category = level, n = nrow(z), missing_outcome = sum(is.na(z$y)),
                 missing_education = sum(is.na(z$education)), missing_wealth = sum(is.na(z$wealth_group)))
    }))
  }))
  write_table(miss, "missingness_by_dimension", out)
  desc <- function(z, label) {
    yp <- z$y[z$positive == 1]
    wp <- z$w10xwgt[z$positive == 1]
    data.frame(
      sample = label, n = nrow(z), households = length(unique(z$idahhw10)), positive = sum(z$positive),
      recurrent = sum(z$y >= 2), unweighted_p = mean(z$positive), weighted_p = weighted.mean(z$positive, z$w10xwgt),
      unweighted_positive_mean = mean(yp), weighted_positive_mean = weighted.mean(yp, wp),
      unweighted_mean = mean(z$y), weighted_mean = weighted.mean(z$y, z$w10xwgt), variance = var(z$y),
      max = max(z$y), age90plus = sum(z$age_topcoded), foreign_other_education = sum(z$education_code == 6),
      wealth_components_imputed = sum(z$wealth_imputed_components > 0), negative_valid_wealth = sum(z$wealth < 0),
      effective_n = sum(z$w10xwgt)^2 / sum(z$w10xwgt^2))
  }
  descriptions <- list(desc(dat, "Primary complete-case personal core sample"))
  for (g in levels(dat$recall_group)) {
    z <- dat[dat$recall_group == g, ]
    if (nrow(z)) descriptions[[length(descriptions) + 1L]] <- desc(z, g)
  }
  write_table(do.call(rbind, descriptions), "descriptive_summary", out)
  duration <- dat$duration_years[dat$duration_known]
  write_table(data.frame(n = length(duration), min = min(duration), median = median(duration),
                         p10 = quantile(duration, 0.1), p90 = quantile(duration, 0.9), max = max(duration),
                         unit = "years from month-resolution wave 9 and wave 10 interviews"),
              "duration_audit", out)
  write_table(data.frame(member = members, zip_sha256 = digest::digest(archive, algo = "sha256", file = TRUE),
                         bytes = inv$Length[match(members, inv$Name)]), "input_provenance", out)

  list(data = dat, grid = grid, strata = strata, eligible = eligible, flow = do.call(rbind, stage), cuts = cuts)
}

# ---------------------------------------------------------------------------
# Model fitting
# ---------------------------------------------------------------------------

# Collapses identical (outcome, stratum, covariate) rows by summing weights. This preserves the
# individual weighted likelihood exactly and speeds up fitting.
compress_data <- function(dat, w) {
  dat$fit_weight <- w
  keep <- c("y", "positive", "sex", "age_group", "education", "wealth_group", "stratum")
  if ("log_duration" %in% names(dat)) keep <- c(keep, "log_duration")
  group <- interaction(dat[keep], drop = TRUE, lex.order = TRUE)
  inds <- split(seq_len(nrow(dat)), group)
  z <- dat[vapply(inds, function(i) i[1], integer(1)), keep, drop = FALSE]
  z$fit_weight <- vapply(inds, function(i) sum(w[i]), numeric(1))
  z <- z[z$fit_weight > 0, ]
  stopifnot(abs(sum(z$fit_weight) - sum(w)) < 1e-07)
  z
}

# Fits one component with glmmTMB.
#   component: "poisson", "nb2", "occurrence" (logistic) or "positive" (zero-truncated NB2 among fallers)
#   spec: "simple" (stratum intercept only) or "additive" (main effects + stratum intercept = MAIHDA)
#   duration: add log duration (offset for counts, covariate for occurrence)
#   fixed_shape: fix the NB2 shape (used for the boundary profile)
# A fit is "good" if the optimiser converged and the Hessian is positive definite; otherwise one
# retry with BFGS is attempted.
fit_component <- function(dat, component, spec = "additive", duration = FALSE, retry = TRUE, fixed_shape = NA_real_) {
  z <- if (component == "positive") dat[dat$y > 0, ] else dat
  response <- if (component == "occurrence") "positive" else "y"
  rhs <- if (spec == "simple") "1 + (1 | stratum)" else "sex + age_group + education + wealth_group + (1 | stratum)"
  if (duration) rhs <- paste(rhs, if (component == "occurrence") "+ log_duration" else "+ offset(log_duration)")
  formula <- as.formula(paste(response, "~", rhs))
  family <- switch(component, poisson = poisson(), nb2 = glmmTMB::nbinom2(), occurrence = binomial(),
                   positive = glmmTMB::truncated_nbinom2())
  fixed <- is.finite(fixed_shape)
  warning_text <- character()
  start <- proc.time()[["elapsed"]]
  attempt <- function(optimizer = FALSE) {
    control <- if (optimizer) {
      glmmTMB::glmmTMBControl(optimizer = optim, optArgs = list(method = "BFGS"), optCtrl = list(maxit = 2000))
    } else {
      glmmTMB::glmmTMBControl(optCtrl = list(iter.max = 2000, eval.max = 3000, rel.tol = 1e-10))
    }
    tryCatch(withCallingHandlers(
      glmmTMB::glmmTMB(formula, data = z, weights = fit_weight, family = family,
                       map = if (fixed) list(betadisp = factor(NA)) else NULL,
                       start = if (fixed) list(betadisp = log(fixed_shape)) else NULL,
                       control = control),
      warning = function(w) {
        warning_text <<- c(warning_text, conditionMessage(w))
        invokeRestart("muffleWarning")
      }), error = function(e) e)
  }
  good <- function(f) !inherits(f, "error") && isTRUE(f$fit$convergence == 0) && isTRUE(f$sdr$pdHess)
  f <- attempt()
  retried <- FALSE
  if (!good(f) && retry) {
    alt <- attempt(TRUE)
    retried <- TRUE
    if (good(alt) || inherits(f, "error")) f <- alt
  }
  failed <- inherits(f, "error")
  has_shape <- !failed && !component %in% c("poisson", "occurrence")
  variance <- if (failed) NA_real_ else as.numeric(glmmTMB::VarCorr(f)$cond$stratum[1, 1])
  gradient <- if (failed) NA_real_ else tryCatch(max(abs(f$obj$gr(f$fit$par))), error = function(e) NA_real_)
  diagnostic <- data.frame(
    component = component, specification = spec, fit_returned = !failed,
    optimiser_ok = if (failed) FALSE else f$fit$convergence == 0,
    hessian_ok = if (failed) FALSE else isTRUE(f$sdr$pdHess),
    good = good(f), random_variance = variance,
    boundary = if (failed) NA else variance < 1e-08,
    dispersion = if (has_shape) as.numeric(sigma(f)) else NA_real_,
    dispersion_boundary = if (has_shape) as.numeric(sigma(f)) < 1e-06 else FALSE,
    max_gradient = gradient, retried = retried, seconds = proc.time()[["elapsed"]] - start,
    warnings = paste(unique(warning_text), collapse = " | "), error = if (failed) conditionMessage(f) else "")
  list(fit = if (failed) NULL else f, diagnostic = diagnostic)
}

# Fits Poisson, NB2 and both hurdle components for each specification, and returns predictions
# for every stratum in `grid`.
fit_set <- function(dat, w, grid, specs = c("simple", "additive"), duration = FALSE) {
  compressed <- compress_data(dat, w)
  fits <- list()
  diags <- list()
  preds <- list()
  for (spec in specs) {
    components <- list()
    for (comp in c("poisson", "nb2", "occurrence", "positive")) {
      id <- paste(spec, comp, sep = "_")
      components[[comp]] <- fit_component(compressed, comp, spec, duration)
      fits[[id]] <- components[[comp]]$fit
      diags[[id]] <- components[[comp]]$diagnostic
    }
    for (model in c("Poisson", "NB2", "Hurdle NB2")) {
      need <- switch(model, Poisson = "poisson", NB2 = "nb2", `Hurdle NB2` = c("occurrence", "positive"))
      good <- all(vapply(components[need], function(z) isTRUE(z$diagnostic$good), logical(1)))
      pr <- tryCatch(predict_distribution(fits, grid, spec, model), error = function(e) {
        data.frame(p = rep(NA_real_, nrow(grid)), m_plus = NA_real_, total_mean = NA_real_,
                   recurrent_given_positive = NA_real_, parent_mu = NA_real_, shape = NA_real_)
      })
      preds[[paste(spec, model)]] <- cbind(grid[, 1:5], specification = spec, model = model,
                                           diagnostic_ok = good && all(is.finite(pr$total_mean)), pr)
    }
  }
  list(fits = fits, diagnostics = do.call(rbind, diags), predictions = do.call(rbind, preds))
}

# Coherent stratum predictions from one model's fitted distribution.
# For NB2-type components, `mu` is the parent (untruncated) mean and `shape` the NB2 size;
# the mean among positives is mu / Pr(Y > 0 | parent).
predict_distribution <- function(fits, grid, spec, model) {
  grid$fit_weight <- 1
  get <- function(c) fits[[paste(spec, c, sep = "_")]]
  if (model == "Poisson") {
    mu <- exp(num(predict(get("poisson"), newdata = grid, type = "link", allow.new.levels = TRUE)))
    mass <- -expm1(-mu)
    p <- mass
    mp <- mu / mass
    rec <- ppois(1, mu, lower.tail = FALSE) / mass
    shape <- Inf
  } else {
    f <- get(if (model == "NB2") "nb2" else "positive")
    mu <- exp(num(predict(f, newdata = grid, type = "link", allow.new.levels = TRUE)))
    shape <- as.numeric(sigma(f))
    mass <- -expm1(-shape * log1p(mu / shape))
    mp <- mu / mass
    rec <- pnbinom(1, mu = mu, size = shape, lower.tail = FALSE) / mass
    p <- if (model == "NB2") mass else plogis(num(predict(get("occurrence"), newdata = grid, type = "link", allow.new.levels = TRUE)))
    if (model == "Hurdle NB2") {
      # glmmTMB's response-scale prediction for truncated_nbinom2 is already the positive mean.
      r <- num(predict(f, newdata = grid, type = "response", allow.new.levels = TRUE))
      stopifnot(max(abs(r - mp)) < 1e-05 * max(1, max(mp)))
    }
  }
  result <- data.frame(p = p, m_plus = mp, total_mean = p * mp, recurrent_given_positive = rec,
                       parent_mu = mu, shape = shape)
  stopifnot(all(is.finite(result$p)), all(is.finite(result$m_plus)), all(result$p > 0 & result$p < 1),
            all(result$m_plus >= 1 - 1e-08),
            all(result$recurrent_given_positive >= 0 & result$recurrent_given_positive <= 1),
            max(abs(result$total_mean - result$p * result$m_plus)) < 1e-10)
  result
}

# Log probability of observed counts under each model (for held-out log scores).
log_probability <- function(y, pred, model) {
  if (model == "Poisson") return(dpois(y, lambda = pred$parent_mu, log = TRUE))
  ll <- dnbinom(y, mu = pred$parent_mu, size = pred$shape, log = TRUE)
  if (model == "NB2") return(ll)
  mass <- -expm1(-pred$shape * log1p(pred$parent_mu / pred$shape))
  ifelse(y == 0, log1p(-pred$p), log(pred$p) + ll - log(mass))
}

# 01 Prepare the analytic sample and fit the primary models.
# Fits Poisson, NB2 and hurdle NB2 with (a) a stratum intercept only ("simple") and
# (b) main effects plus a stratum intercept ("additive" = MAIHDA), with and without survey weights.
source("R/setup.R")

p <- load_falls(data_dir, out_main)
saveRDS(p, file.path(private_dir, "prepared.rds"))
print(p$flow)

for (weighting in c("survey", "unweighted")) {
  w <- if (weighting == "survey") p$data$weight else rep(1, nrow(p$data))
  r <- fit_set(p$data, w, p$grid)
  saveRDS(r, file.path(private_dir, paste0("main_", weighting, ".rds")))
  write_table(cbind(weighting = weighting, r$diagnostics), paste0("diagnostics_", weighting), out_main)
  write_table(cbind(weighting = weighting, r$predictions), paste0("predictions_", weighting), out_main)
  print(r$diagnostics[, c("component", "specification", "good", "random_variance", "dispersion")])
}
writeLines(capture.output(sessionInfo()), file.path(out_main, "session_info.txt"))
cat("01 complete\n")

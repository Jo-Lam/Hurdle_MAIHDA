# 02 Sensitivity analyses, positive-count shape profile, household-held-out validation and calibration.
source("R/setup.R")
p <- readRDS(file.path(private_dir, "prepared.rds"))
dat <- p$data
main <- readRDS(file.path(private_dir, "main_survey.rds"))

# ---- Sensitivity analyses (MAIHDA specification only) ----
scenarios <- list(
  no_counts_above20 = dat[dat$y <= 20, ],
  no_imputed_wealth_components = dat[dat$wealth_imputed_components == 0, ],
  known_w9_interval = dat[dat$duration_known, ])
sens <- list()
sensdiag <- list()
for (name in names(scenarios)) {
  z <- scenarios[[name]]
  duration <- name == "known_w9_interval"
  grid <- p$grid
  if (duration) {
    # Log duration: offset in count components, covariate for occurrence; predictions at 3.5 years.
    z$log_duration <- log(z$duration_years)
    grid$log_duration <- log(3.5)
  }
  r <- fit_set(z, z$w10xwgt / mean(z$w10xwgt), grid, specs = "additive", duration = duration)
  sens[[name]] <- cbind(sensitivity = name, n = nrow(z), positive = sum(z$positive),
                        standardised_duration_years = if (duration) 3.5 else NA_real_, r$predictions)
  sensdiag[[name]] <- cbind(sensitivity = name, r$diagnostics)
  saveRDS(r, file.path(private_dir, paste0("sensitivity_", name, ".rds")))
  cat("Sensitivity", name, "N", nrow(z), "\n")
}
write_table(do.call(rbind, sens), "sensitivity_predictions", out_main)
write_table(do.call(rbind, sensdiag), "sensitivity_diagnostics", out_main)

# ---- Profile over a fixed positive-count NB2 shape (the estimate lies at the boundary) ----
compressed <- compress_data(dat, dat$weight)
base <- main$predictions[main$predictions$specification == "additive" & main$predictions$model == "Hurdle NB2", ]
shape_rows <- list()
shape_preds <- list()
for (shape in c(1e-06, 0.001, 0.01, 0.1, 0.5, 1, 2)) {
  z <- fit_component(compressed, "positive", fixed_shape = shape)
  fits <- main$fits
  fits$additive_positive <- z$fit
  pr <- tryCatch(predict_distribution(fits, p$grid, "additive", "Hurdle NB2"), error = function(e) NULL)
  shape_rows[[as.character(shape)]] <- data.frame(
    fixed_shape = shape, z$diagnostic,
    log_pseudo_likelihood = if (is.null(z$fit)) NA_real_ else as.numeric(logLik(z$fit)),
    max_absolute_change_positive_mean = if (is.null(pr)) NA_real_ else max(abs(pr$m_plus - base$m_plus)),
    max_relative_change_positive_mean = if (is.null(pr)) NA_real_ else max(abs(pr$m_plus / base$m_plus - 1)))
  if (!is.null(pr)) shape_preds[[as.character(shape)]] <- cbind(fixed_shape = shape, p$grid[, 1:5], pr)
}
write_table(do.call(rbind, shape_rows), "positive_shape_profile", out_main)
write_table(do.call(rbind, shape_preds), "positive_shape_predictions", out_main)

# ---- Household-held-out cross-validation (MAIHDA specification) ----
set.seed(SEED)
hh <- unique(dat$idahhw10)
assignment <- sample(rep(seq_len(N_FOLDS), length.out = length(hh)))
fold_id <- assignment[match(dat$idahhw10, hh)]
oof <- list()
cvdiag <- list()
for (weighting in c("survey", "unweighted")) for (k in seq_len(N_FOLDS)) {
  train <- dat[fold_id != k, ]
  test <- dat[fold_id == k, ]
  w <- if (weighting == "survey") train$w10xwgt / mean(train$w10xwgt) else rep(1, nrow(train))
  r <- fit_set(train, w, p$grid, specs = "additive")
  cvdiag[[paste(weighting, k)]] <- cbind(weighting = weighting, fold = k, r$diagnostics)
  for (model in c("Poisson", "NB2", "Hurdle NB2")) {
    pr <- r$predictions[r$predictions$model == model, ]
    pred <- pr[match(test$stratum, pr$stratum), ]
    ll <- log_probability(test$y, pred, model)
    oof[[paste(weighting, k, model)]] <- data.frame(
      weighting = weighting, fold = k, model = model, household = test$idahhw10, w = test$w10xwgt, y = test$y,
      positive = test$positive, p = pred$p, m_plus = pred$m_plus, total_mean = pred$total_mean, ll = ll,
      positive_ll = ifelse(test$y > 0, ll - log(pred$p), NA_real_), diagnostic_ok = all(pr$diagnostic_ok))
  }
  cat("CV", weighting, k, "\n")
}
oof <- do.call(rbind, oof)
saveRDS(oof, file.path(private_dir, "cv_private.rds"))
write_table(do.call(rbind, cvdiag), "cv_diagnostics", out_main)
cvsum <- do.call(rbind, lapply(split(oof, interaction(oof$weighting, oof$model, drop = TRUE)), function(z) {
  pos <- z$positive == 1
  data.frame(
    weighting = z$weighting[1], model = z$model[1], n = nrow(z), all_folds_diagnostic_ok = all(z$diagnostic_ok),
    weighted_mean_log_score = weighted.mean(z$ll, z$w), unweighted_mean_log_score = mean(z$ll),
    weighted_occurrence_brier = weighted.mean((z$positive - z$p)^2, z$w),
    weighted_positive_log_score = weighted.mean(z$positive_ll[pos], z$w[pos]),
    observed_occurrence = weighted.mean(z$positive, z$w), predicted_occurrence = weighted.mean(z$p, z$w),
    observed_positive_mean = weighted.mean(z$y[pos], z$w[pos]),
    predicted_positive_mean_among_actual_fallers = weighted.mean(z$m_plus[pos], z$w[pos]),
    observed_total_mean = weighted.mean(z$y, z$w), predicted_total_mean = weighted.mean(z$total_mean, z$w))
}))
write_table(cvsum, "cross_validation_summary", out_main)

# Paired score differences: households resampled 2,000 times with fitted folds held fixed.
set.seed(SEED + 1L)
score_pairs <- list()
for (pair in list(c("Hurdle NB2", "NB2"), c("NB2", "Poisson"), c("Hurdle NB2", "Poisson"))) {
  a <- oof[oof$weighting == "survey" & oof$model == pair[1], ]
  b <- oof[oof$weighting == "survey" & oof$model == pair[2], ]
  stopifnot(identical(a$household, b$household), identical(a$y, b$y))
  ds <- a$ll - b$ll
  group <- split(seq_len(nrow(a)), a$household)
  num_h <- vapply(group, function(i) sum(a$w[i] * ds[i]), numeric(1))
  den_h <- vapply(group, function(i) sum(a$w[i]), numeric(1))
  boot <- replicate(2000L, {
    j <- sample.int(length(group), length(group), replace = TRUE)
    sum(num_h[j]) / sum(den_h[j])
  })
  score_pairs[[paste(pair, collapse = "_")]] <- data.frame(
    first = pair[1], second = pair[2], weighted_logscore_difference = weighted.mean(ds, a$w),
    lower = quantile(boot, 0.025), upper = quantile(boot, 0.975),
    note = "Household score bootstrap; fixed fitted CV folds, not full refit uncertainty")
}
write_table(do.call(rbind, score_pairs), "paired_cv_logscore_differences", out_main)

# ---- Calibration: in-sample count distribution and out-of-fold occurrence ----
calibration <- list()
for (weighting in c("survey", "unweighted")) for (model in c("Poisson", "NB2", "Hurdle NB2")) {
  z <- oof[oof$weighting == weighting & oof$model == model, ]
  r <- readRDS(file.path(private_dir, paste0("main_", weighting, ".rds")))
  pr <- r$predictions[r$predictions$model == model & r$predictions$specification == "additive", ]
  full <- pr[match(dat$stratum, pr$stratum), ]
  for (k in c(0, 1, 2, 5, 10, 20)) {
    prob <- if (model == "Poisson") {
      if (k <= 1) dpois(k, full$parent_mu) else ppois(k - 1, full$parent_mu, lower.tail = FALSE)
    } else {
      parent <- if (k <= 1) dnbinom(k, mu = full$parent_mu, size = full$shape)
                else pnbinom(k - 1, mu = full$parent_mu, size = full$shape, lower.tail = FALSE)
      if (model == "NB2") parent
      else if (k == 0) 1 - full$p
      else full$p * parent / (-expm1(-full$shape * log1p(full$parent_mu / full$shape)))
    }
    observed <- if (k <= 1) dat$y == k else dat$y >= k
    calibration[[paste(weighting, model, k)]] <- data.frame(
      weighting = weighting, model = model, event = if (k <= 1) paste0("Y=", k) else paste0("Y>=", k),
      observed = weighted.mean(observed, dat$w10xwgt), predicted = weighted.mean(prob, dat$w10xwgt),
      type = "In-sample distribution check, weighted target sample")
  }
  bins <- cut(z$p, breaks = unique(quantile(z$p, seq(0, 1, 0.2))), include.lowest = TRUE)
  for (level in levels(bins)) {
    q <- z[bins == level, ]
    calibration[[paste(weighting, model, level)]] <- data.frame(
      weighting = weighting, model = model, event = paste0("Occurrence group ", level),
      observed = weighted.mean(q$positive, q$w), predicted = weighted.mean(q$p, q$w),
      type = "Out-of-fold occurrence calibration")
  }
}
write_table(do.call(rbind, calibration), "calibration", out_main)
cat("02 complete\n")

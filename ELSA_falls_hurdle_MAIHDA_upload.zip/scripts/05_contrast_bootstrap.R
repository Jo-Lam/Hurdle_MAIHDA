# 05 Paired household bootstrap of hurdle stratum departures (additive-only and MAIHDA refitted
# in the same 200 resamples, using the same household draws as script 03), with pointwise
# intervals, an approximate simultaneous screen and direction stability.
source("R/setup.R")
p <- readRDS(file.path(private_dir, "prepared.rds"))
dat <- p$data
grid <- p$grid

config <- list(seed = SEED, B = N_BOOT, components = c("occurrence", "positive"),
               function_hash = digest::digest(file.path(root, "R", "falls_functions.R"), file = TRUE, algo = "sha256"),
               contrast_hash = digest::digest(file.path(root, "R", "contrast_functions.R"), file = TRUE, algo = "sha256"))
hash <- digest::digest(config)
checkpoint <- file.path(private_dir, "bootstrap_contrasts")
dir.create(checkpoint, showWarnings = FALSE)
hh <- unique(dat$idahhw10)
hi <- match(dat$idahhw10, hh)

for (b in seq_len(N_BOOT)) {
  file <- file.path(checkpoint, sprintf("replicate_%03d.rds", b))
  if (file.exists(file)) {
    stopifnot(identical(readRDS(file)$hash, hash))
    next
  }
  set.seed(SEED + 1000L + b)
  counts <- tabulate(sample.int(length(hh), length(hh), TRUE), nbins = length(hh))
  mult <- counts[hi]
  keep <- mult > 0
  d <- dat[keep, ]
  w <- d$w10xwgt * mult[keep]
  w <- w * sum(mult) / sum(w)
  fixed <- fit_fixed(d, w, grid, components = c("occurrence", "positive"))
  cmp <- compress_data(d, w)
  oc <- fit_component(cmp, "occurrence")
  po <- fit_component(cmp, "positive")
  fits <- list(additive_occurrence = oc$fit, additive_positive = po$fit)
  good <- all(fixed$diagnostics$good, oc$diagnostic$good, po$diagnostic$good)
  result <- tryCatch({
    a <- predict_distribution(fits, grid, "additive", "Hurdle NB2")
    z <- zero_re_prediction(fits, grid, "Hurdle NB2")
    f <- fixed$predictions
    data.frame(replication = b, stratum = grid$stratum, good = good,
               p_log_interaction = log(a$p / z$p), m_plus_log_interaction = log(a$m_plus / z$m_plus),
               total_mean_log_interaction = log(a$total_mean / z$total_mean),
               p_log_model_difference = log(a$p / f$p), m_plus_log_model_difference = log(a$m_plus / f$m_plus),
               total_mean_log_model_difference = log(a$total_mean / f$total_mean),
               p_maihda = a$p, m_plus_maihda = a$m_plus, total_mean_maihda = a$total_mean,
               p_fixed = f$p, m_plus_fixed = f$m_plus, total_mean_fixed = f$total_mean)
  }, error = function(e) data.frame(replication = b, stratum = grid$stratum, good = FALSE, error = conditionMessage(e)))
  saveRDS(list(hash = hash, config = config, predictions = result,
               diagnostics = list(fixed = fixed$diagnostics, occurrence = oc$diagnostic, positive = po$diagnostic)), file)
  if (b %% 10L == 0L) cat("Contrast bootstrap", b, "/", N_BOOT, "\n")
}

# ---- Summaries ----
point <- read_out(out_contrasts, "stratum_contrasts")
point <- point[point$model == "Hurdle NB2", ]
reps <- lapply(file.path(checkpoint, sprintf("replicate_%03d.rds", seq_len(N_BOOT))), readRDS)
stopifnot(length(unique(vapply(reps, "[[", character(1), "hash"))) == 1)
complete <- vapply(reps, function(r) all(r$predictions$good), logical(1))
stopifnot(sum(complete) >= 0.8 * N_BOOT)
b <- lapply(reps[complete], "[[", "predictions")
stopifnot(all(vapply(b, function(z) identical(as.character(z$stratum), as.character(point$stratum)), logical(1))))

metrics <- c("p_log_interaction", "m_plus_log_interaction", "total_mean_log_interaction",
             "p_log_model_difference", "m_plus_log_model_difference", "total_mean_log_model_difference")
rows <- list()
matrices <- list()
for (metric in metrics) {
  m <- do.call(rbind, lapply(b, "[[", metric))
  stopifnot(all(is.finite(m)))
  matrices[[metric]] <- m
  lo <- apply(m, 2, quantile, 0.025)
  hi <- apply(m, 2, quantile, 0.975)
  rows[[metric]] <- data.frame(
    stratum = point$stratum, metric = metric, estimate = point[[metric]], lower = lo, upper = hi,
    bootstrap_mean = colMeans(m), bootstrap_sd = apply(m, 2, sd), positive_fraction = colMeans(m > 0),
    same_sign_fraction = colMeans(sweep(m, 2, sign(point[[metric]]), "*") > 0),
    pointwise_excludes_zero = lo > 0 | hi < 0, attempted = N_BOOT, available = sum(complete))
}
ci <- do.call(rbind, rows)

# Approximate simultaneous screen: 95th percentile of the maximum absolute standardised deviation
# across all occurrence and frequency departures. An exploratory resampling screen, not an exact test.
for (kind in c("interaction", "model_difference")) {
  mets <- paste0(c("p", "m_plus"), "_log_", kind)
  m <- do.call(cbind, matrices[mets])
  estimate <- unlist(point[mets], use.names = FALSE)
  sd <- apply(m, 2, sd)
  active <- sd > 1e-10
  dev <- sweep(sweep(m[, active, drop = FALSE], 2, estimate[active], "-"), 2, sd[active], "/")
  crit <- quantile(apply(abs(dev), 1, max), 0.95)
  for (metric in mets) {
    i <- which(ci$metric == metric)
    ci$simultaneous_lower[i] <- ci$estimate[i] - crit * ci$bootstrap_sd[i]
    ci$simultaneous_upper[i] <- ci$estimate[i] + crit * ci$bootstrap_sd[i]
    ci$simultaneous_critical[i] <- crit
  }
}
# No interval for frequency departures in a stratum without fallers.
ci$direct_positive_information <- point$n_positive[match(ci$stratum, point$stratum)] > 0
empty <- !ci$direct_positive_information & grepl("^m_plus", ci$metric)
ci[empty, c("lower", "upper", "simultaneous_lower", "simultaneous_upper")] <- NA_real_
ci$pointwise_excludes_zero[empty] <- FALSE
ci$simultaneous_excludes_zero <- ci$simultaneous_lower > 0 | ci$simultaneous_upper < 0
write_table(ci, "hurdle_contrast_intervals", out_contrasts)

occ <- matrices$p_log_interaction
pos <- matrices$m_plus_log_interaction
direction <- data.frame(
  stratum = point$stratum, point_direction = point$direction,
  bootstrap_same_fraction = colMeans(occ * pos > 0), bootstrap_opposite_fraction = colMeans(occ * pos < 0),
  both_point_signs_fraction = colMeans(sign(occ) == rep(sign(point$p_log_interaction), each = nrow(occ)) &
                                         sign(pos) == rep(sign(point$m_plus_log_interaction), each = nrow(pos))))
direction$both_point_signs_fraction[point$n_positive == 0] <- NA_real_
write_table(direction, "direction_stability", out_contrasts)

write_table(do.call(rbind, lapply(seq_along(reps), function(i) {
  r <- reps[[i]]
  fx <- r$diagnostics$fixed
  data.frame(replication = i, complete = complete[i],
             fixed_occurrence_good = fx$good[fx$component == "occurrence"], fixed_positive_good = fx$good[fx$component == "positive"],
             maihda_occurrence_good = r$diagnostics$occurrence$good, maihda_positive_good = r$diagnostics$positive$good,
             occurrence_variance = r$diagnostics$occurrence$random_variance,
             positive_variance = r$diagnostics$positive$random_variance, positive_shape = r$diagnostics$positive$dispersion)
})), "contrast_bootstrap_diagnostics", out_contrasts)

summary <- do.call(rbind, lapply(split(ci, ci$metric), function(z) {
  data.frame(metric = z$metric[1], pointwise_excludes_zero = sum(z$pointwise_excludes_zero),
             simultaneous_excludes_zero = sum(z$simultaneous_excludes_zero, na.rm = TRUE),
             maximum_same_sign_fraction = max(z$same_sign_fraction))
}))
write_table(summary, "interaction_support_summary", out_contrasts)
print(summary)
cat("05 complete:", sum(complete), "of", N_BOOT, "replicates complete\n")

# 06 Numerical verification checks. Stops with an error if any check fails.
source("R/setup.R")
p <- readRDS(file.path(private_dir, "prepared.rds"))
grid <- p$grid
r <- readRDS(file.path(private_dir, "main_survey.rds"))
f <- readRDS(file.path(private_dir, "fixed_only_survey.rds"))
checks <- list()

# 1. Compressing identical rows reproduces the individual-level weighted fit.
d <- p$data
d$fit_weight <- d$weight
for (comp in c("poisson", "nb2", "occurrence")) {
  full <- fit_component(d, comp)
  stored <- r$fits[[paste0("additive_", comp)]]
  a <- as.numeric(predict(full$fit, newdata = transform(grid, fit_weight = 1), type = "link"))
  b <- as.numeric(predict(stored, newdata = transform(grid, fit_weight = 1), type = "link"))
  delta <- max(abs(a - b))
  ll <- abs(as.numeric(logLik(full$fit)) - as.numeric(logLik(stored)))
  stopifnot(full$diagnostic$good, delta < 0.001, ll < 0.001)
  checks[[comp]] <- data.frame(check = paste("Compression", comp), maximum_error = max(delta, ll))
}

# 2. Each model's predicted count distribution sums to one.
for (model in c("Poisson", "NB2", "Hurdle NB2")) {
  pr <- predict_distribution(r$fits, grid, "additive", model)
  summed <- vapply(seq_len(nrow(pr)), function(j) {
    ys <- 0:1e+05
    sum(exp(log_probability(ys, pr[rep(j, length(ys)), ], model)))
  }, numeric(1))
  stopifnot(max(abs(summed - 1)) < 1e-06)
  checks[[model]] <- data.frame(check = paste("Probability normalisation", model), maximum_error = max(abs(summed - 1)))
}

# 3. MAIHDA minus zero-random-effect link predictions equal the conditional modes.
g <- grid
g$fit_weight <- 1
for (comp in c("occurrence", "positive")) {
  fit <- r$fits[[paste0("additive_", comp)]]
  u <- as.numeric(predict(fit, g, type = "link", allow.new.levels = TRUE) -
                    predict(fit, g, type = "link", re.form = NA, allow.new.levels = TRUE))
  re <- glmmTMB::ranef(fit)$cond$stratum
  expected <- re[match(grid$stratum, rownames(re)), 1]
  expected[is.na(expected)] <- 0
  stopifnot(max(abs(u - expected)) < 1e-08)
  checks[[paste("re", comp)]] <- data.frame(check = paste("Random-effect identity", comp), maximum_error = max(abs(u - expected)))
}

# 4. Hurdle-only and full additive-only refits agree.
ff <- fit_fixed(p$data, p$data$weight, grid, components = c("occurrence", "positive"))
delta <- max(abs(ff$predictions$m_plus - f$predictions$m_plus[f$predictions$model == "Hurdle NB2"]))
stopifnot(delta < 1e-06)
checks[["partial"]] <- data.frame(check = "Hurdle-only and full additive-only refits agree", maximum_error = delta)

# 5. The contrast bootstrap reproduces the MAIHDA hurdle predictions of the main bootstrap.
errors <- vapply(seq_len(N_BOOT), function(b) {
  old <- readRDS(file.path(private_dir, "bootstrap_main", sprintf("replicate_%03d.rds", b)))$predictions
  old <- old[old$specification == "additive" & old$model == "Hurdle NB2", ]
  new <- readRDS(file.path(private_dir, "bootstrap_contrasts", sprintf("replicate_%03d.rds", b)))$predictions
  stopifnot(all(new$good), identical(as.character(old$stratum), as.character(new$stratum)),
            max(abs(new$total_mean_log_interaction - new$p_log_interaction - new$m_plus_log_interaction)) < 1e-10)
  max(abs(old$p - new$p_maihda), abs(old$m_plus - new$m_plus_maihda))
}, numeric(1))
stopifnot(max(errors) < 1e-05)
checks[["resamples"]] <- data.frame(check = "Contrast bootstrap reproduces main bootstrap", maximum_error = max(errors))

# 6. Poisson and NB2 stratum departures always move occurrence and frequency together.
a <- read_out(out_contrasts, "stratum_contrasts")
z <- a[a$model %in% c("Poisson", "NB2"), ]
stopifnot(all(z$p_log_interaction * z$m_plus_log_interaction >= -1e-12))
checks[["monotonic"]] <- data.frame(check = "Single-distribution departures share direction", maximum_error = 0)
stopifnot(all(read_out(out_contrasts, "fixed_only_cv_diagnostics")$good))

write_table(cbind(do.call(rbind, checks), passed = TRUE), "verification_checks", out_main)
cat("06 complete: all checks passed\n")

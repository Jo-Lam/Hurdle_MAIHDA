# 08 Does the held-out hurdle advantage over NB2 survive excluding counts above 20?
# Same household folds as script 02; counts above 20 removed from training and test sets.
# Excluding high counts changes the estimand: an influence sensitivity, not a corrected analysis.
source("R/setup.R")
p <- readRDS(file.path(private_dir, "prepared.rds"))
dat <- p$data
grid <- p$grid

set.seed(SEED)
hh <- unique(dat$idahhw10)
assignment <- sample(rep(seq_len(N_FOLDS), length.out = length(hh)))
dat$fold <- assignment[match(dat$idahhw10, hh)]
d <- dat[dat$y <= 20, ]
oof <- list()
diags <- list()
for (k in seq_len(N_FOLDS)) {
  train <- d[d$fold != k, ]
  test <- d[d$fold == k, ]
  w <- train$w10xwgt / mean(train$w10xwgt)
  fits <- list(MAIHDA = fit_set(train, w, grid, specs = "additive"), `Fixed-only` = fit_fixed(train, w, grid))
  for (structure in names(fits)) {
    r <- fits[[structure]]
    diags[[paste(k, structure)]] <- cbind(fold = k, structure = structure,
                                          r$diagnostics[, intersect(c("component", "good", "dispersion"), names(r$diagnostics))])
    for (model in c("Poisson", "NB2", "Hurdle NB2")) {
      pr <- r$predictions[r$predictions$model == model, ]
      pred <- pr[match(test$stratum, pr$stratum), ]
      oof[[paste(k, structure, model)]] <- data.frame(
        structure = structure, model = model, fold = k, household = test$idahhw10, w = test$w10xwgt, y = test$y,
        positive = test$positive, p = pred$p, m_plus = pred$m_plus, total_mean = pred$total_mean,
        ll = log_probability(test$y, pred, model))
    }
  }
}
oof <- do.call(rbind, oof)
write_table(do.call(rbind, diags), "tail_cv_diagnostics", out_contrasts)
write_table(do.call(rbind, lapply(split(oof, interaction(oof$structure, oof$model, drop = TRUE)), function(z) {
  pos <- z$positive == 1
  data.frame(structure = z$structure[1], model = z$model[1], n = nrow(z), weighted_log_score = weighted.mean(z$ll, z$w),
             occurrence_brier = weighted.mean((z$positive - z$p)^2, z$w),
             observed_occurrence = weighted.mean(z$positive, z$w), predicted_occurrence = weighted.mean(z$p, z$w),
             observed_positive_mean = weighted.mean(z$y[pos], z$w[pos]),
             predicted_positive_mean = weighted.mean(z$m_plus[pos], z$w[pos]))
})), "tail_cv_scores", out_contrasts)

paired <- function(a, b, label) {
  stopifnot(identical(a$household, b$household), identical(a$y, b$y))
  ds <- a$ll - b$ll
  g <- split(seq_len(nrow(a)), a$household)
  nh <- vapply(g, function(i) sum(a$w[i] * ds[i]), numeric(1))
  dh <- vapply(g, function(i) sum(a$w[i]), numeric(1))
  boot <- replicate(2000, {
    j <- sample.int(length(g), length(g), TRUE)
    sum(nh[j]) / sum(dh[j])
  })
  data.frame(comparison = label, difference = weighted.mean(ds, a$w), lower = quantile(boot, 0.025), upper = quantile(boot, 0.975))
}
pick <- function(x, s, m) x[x$structure == s & x$model == m, ]
set.seed(SEED + 2L)
res <- list(
  paired(pick(oof, "MAIHDA", "Hurdle NB2"), pick(oof, "MAIHDA", "NB2"), "Counts <=20: hurdle MAIHDA minus NB2 MAIHDA"),
  paired(pick(oof, "Fixed-only", "Hurdle NB2"), pick(oof, "Fixed-only", "NB2"), "Counts <=20: additive hurdle minus additive NB2"),
  paired(pick(oof, "MAIHDA", "Hurdle NB2"), pick(oof, "Fixed-only", "Hurdle NB2"), "Counts <=20: hurdle MAIHDA minus additive hurdle"))
full <- readRDS(file.path(private_dir, "contrast_oof.rds"))
res[[4]] <- paired(pick(full, "Fixed-only", "Hurdle NB2"), pick(full, "Fixed-only", "NB2"), "All counts: additive hurdle minus additive NB2")
res <- do.call(rbind, res)
res$note <- "Household score bootstrap (2000); fitted folds held fixed"
write_table(res, "tail_cv_paired_scores", out_contrasts)
print(res)
cat("08 complete\n")

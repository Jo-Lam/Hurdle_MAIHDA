# 04 Additive-only models versus MAIHDA: stratum departures and paired held-out scores.
# Separates the contribution of the count distribution (Poisson / NB2 / hurdle) from that of
# stratum random effects (additive-only versus MAIHDA within each family).
source("R/setup.R")
p <- readRDS(file.path(private_dir, "prepared.rds"))
dat <- p$data
grid <- p$grid
main <- readRDS(file.path(private_dir, "main_survey.rds"))

fixed <- fit_fixed(dat, dat$weight, grid)
saveRDS(fixed, file.path(private_dir, "fixed_only_survey.rds"))
write_table(fixed$diagnostics, "fixed_only_diagnostics", out_contrasts)
write_table(fixed$predictions, "fixed_only_predictions", out_contrasts)

# Per-stratum comparisons. "_log_interaction": MAIHDA versus the same fit with stratum effects set
# to zero. "_log_model_difference": MAIHDA versus the separately fitted additive-only model.
contrasts <- list()
for (model in c("Poisson", "NB2", "Hurdle NB2")) {
  a <- main$predictions[main$predictions$specification == "additive" & main$predictions$model == model, ]
  b <- fixed$predictions[fixed$predictions$model == model, ]
  z <- zero_re_prediction(main$fits, grid, model)
  stopifnot(identical(as.character(a$stratum), as.character(b$stratum)))
  r <- cbind(grid[, 1:5], model = model, n = p$strata$n, n_positive = p$strata$n_positive,
             n_recurrent = p$strata$n_recurrent)
  for (t in c("p", "m_plus", "total_mean")) {
    r[[paste0(t, "_maihda")]] <- a[[t]]
    r[[paste0(t, "_fixed_only")]] <- b[[t]]
    r[[paste0(t, "_zero_re")]] <- z[[t]]
    r[[paste0(t, "_log_interaction")]] <- log(a[[t]] / z[[t]])
    r[[paste0(t, "_log_model_difference")]] <- log(a[[t]] / b[[t]])
    r[[paste0(t, "_rank_maihda")]] <- rank(-a[[t]], ties.method = "min")
    r[[paste0(t, "_rank_fixed_only")]] <- rank(-b[[t]], ties.method = "min")
  }
  r$direction <- ifelse(abs(r$p_log_interaction) < 1e-06 | abs(r$m_plus_log_interaction) < 1e-06, "Near-zero component",
                        ifelse(r$p_log_interaction * r$m_plus_log_interaction > 0, "Same", "Opposite"))
  stopifnot(max(abs(r$total_mean_log_interaction - r$p_log_interaction - r$m_plus_log_interaction)) < 1e-10)
  contrasts[[model]] <- r
}
write_table(do.call(rbind, contrasts), "stratum_contrasts", out_contrasts)

# Conditional modes of the stratum effects (descriptive; parameter uncertainty omitted).
write_table(do.call(rbind, lapply(c("poisson", "nb2", "occurrence", "positive"), function(comp) {
  z <- glmmTMB::ranef(main$fits[[paste0("additive_", comp)]], condVar = TRUE)$cond$stratum
  data.frame(component = comp, stratum = rownames(z), conditional_mode = z[[1]],
             conditional_sd = sqrt(as.numeric(attr(z, "condVar"))))
})), "conditional_random_effects", out_contrasts)

# Fixed-effect coefficients for both structures.
coefs <- list()
for (structure in c("Fixed-only", "MAIHDA")) for (comp in c("poisson", "nb2", "occurrence", "positive")) {
  z <- if (structure == "Fixed-only") fixed else main
  b <- glmmTMB::fixef(z$fits[[paste0("additive_", comp)]])$cond
  coefs[[paste(structure, comp)]] <- data.frame(structure = structure, component = comp, term = names(b),
                                                coefficient = as.numeric(b), exponentiated = exp(as.numeric(b)))
}
write_table(do.call(rbind, coefs), "fixed_effect_coefficients", out_contrasts)

# Held-out scores for additive-only models using the same household folds as script 02.
set.seed(SEED)
hh <- unique(dat$idahhw10)
assignment <- sample(rep(seq_len(N_FOLDS), length.out = length(hh)))
fold_id <- assignment[match(dat$idahhw10, hh)]
oof <- list()
cvdi <- list()
for (k in seq_len(N_FOLDS)) {
  train <- dat[fold_id != k, ]
  test <- dat[fold_id == k, ]
  r <- fit_fixed(train, train$w10xwgt / mean(train$w10xwgt), grid)
  cvdi[[k]] <- cbind(fold = k, r$diagnostics)
  for (model in c("Poisson", "NB2", "Hurdle NB2")) {
    pr <- r$predictions[r$predictions$model == model, ]
    pred <- pr[match(test$stratum, pr$stratum), ]
    oof[[paste(k, model)]] <- data.frame(
      structure = "Fixed-only", model = model, fold = k, household = test$idahhw10, w = test$w10xwgt, y = test$y,
      positive = test$positive, p = pred$p, m_plus = pred$m_plus, total_mean = pred$total_mean,
      ll = log_probability(test$y, pred, model))
  }
}
x <- readRDS(file.path(private_dir, "cv_private.rds"))
x <- x[x$weighting == "survey", ]
x$structure <- "MAIHDA"
oof <- do.call(rbind, oof)
oof <- rbind(oof, x[, names(oof)])
saveRDS(oof, file.path(private_dir, "contrast_oof.rds"))
write_table(do.call(rbind, cvdi), "fixed_only_cv_diagnostics", out_contrasts)
write_table(do.call(rbind, lapply(split(oof, interaction(oof$structure, oof$model, drop = TRUE)), function(z) {
  pos <- z$positive == 1
  data.frame(structure = z$structure[1], model = z$model[1], weighted_log_score = weighted.mean(z$ll, z$w),
             occurrence_brier = weighted.mean((z$positive - z$p)^2, z$w), predicted_p = weighted.mean(z$p, z$w),
             predicted_positive_mean = weighted.mean(z$m_plus[pos], z$w[pos]),
             predicted_total_mean = weighted.mean(z$total_mean, z$w))
})), "six_model_validation", out_contrasts)

set.seed(SEED + 1L)
write_table(do.call(rbind, lapply(c("Poisson", "NB2", "Hurdle NB2"), function(model) {
  a <- oof[oof$structure == "MAIHDA" & oof$model == model, ]
  b <- oof[oof$structure == "Fixed-only" & oof$model == model, ]
  stopifnot(identical(a$household, b$household), identical(a$y, b$y))
  ds <- a$ll - b$ll
  group <- split(seq_len(nrow(a)), a$household)
  nh <- vapply(group, function(i) sum(a$w[i] * ds[i]), numeric(1))
  dh <- vapply(group, function(i) sum(a$w[i]), numeric(1))
  boot <- replicate(2000, {
    j <- sample.int(length(group), length(group), TRUE)
    sum(nh[j]) / sum(dh[j])
  })
  data.frame(model = model, MAIHDA_minus_fixed_only = weighted.mean(ds, a$w),
             lower = quantile(boot, 0.025), upper = quantile(boot, 0.975))
})), "paired_structure_scores", out_contrasts)

# Influence of counts above 20 on hurdle stratum departures.
d <- dat[dat$y <= 20, ]
fix_s <- fit_fixed(d, d$w10xwgt / mean(d$w10xwgt), grid)
mai_s <- readRDS(file.path(private_dir, "sensitivity_no_counts_above20.rds"))
a <- mai_s$predictions[mai_s$predictions$model == "Hurdle NB2", ]
b <- fix_s$predictions[fix_s$predictions$model == "Hurdle NB2", ]
z <- zero_re_prediction(mai_s$fits, grid, "Hurdle NB2")
write_table(cbind(grid[, 1:5],
                  n = vapply(grid$stratum, function(s) sum(d$stratum == s), integer(1)),
                  positive = vapply(grid$stratum, function(s) sum(d$stratum == s & d$positive == 1), integer(1)),
                  p_maihda = a$p, m_plus_maihda = a$m_plus, p_fixed = b$p, m_plus_fixed = b$m_plus,
                  p_log_interaction = log(a$p / z$p), m_plus_log_interaction = log(a$m_plus / z$m_plus)),
            "tail_sensitivity_contrasts", out_contrasts)

# Stratum tail audit (contains individual-level extremes: local use only, never release).
write_table(do.call(rbind, lapply(grid$stratum, function(s) {
  z <- dat[dat$stratum == s, ]
  data.frame(stratum = s, n_above20 = sum(z$y > 20), maximum = max(z$y),
             fraction_weighted_events_above20 = sum(z$w10xwgt[z$y > 20] * z$y[z$y > 20]) / sum(z$w10xwgt * z$y))
})), "stratum_tail_audit", file.path(private_dir))
cat("04 complete\n")

# 03 Household bootstrap (200 refits), prediction intervals, PCV and summary tables.
# Replicates are checkpointed under private/bootstrap_main; a changed configuration stops the
# script instead of silently reusing old replicates. Delete that folder to start afresh.
source("R/setup.R")
p <- readRDS(file.path(private_dir, "prepared.rds"))
dat <- p$data

settings <- list(seed = SEED, household_bootstraps = N_BOOT,
                 weight_scaling = "Mean one in replicate sample; same scale in positive subset",
                 intervals = "Percentile; fixed wealth cut-points, strata and supplied imputations",
                 function_hash = digest::digest(file.path(root, "R", "falls_functions.R"), file = TRUE, algo = "sha256"))
config_hash <- digest::digest(settings)
checkpoint <- file.path(private_dir, "bootstrap_main")
dir.create(checkpoint, showWarnings = FALSE)

# Households are resampled with replacement; all members of a sampled household are retained and
# the relative survey weights are multiplied by the number of times the household was drawn.
hh <- unique(dat$idahhw10)
hhindex <- match(dat$idahhw10, hh)
bootpred <- list()
bootdiag <- list()
for (b in seq_len(N_BOOT)) {
  file <- file.path(checkpoint, sprintf("replicate_%03d.rds", b))
  if (file.exists(file)) {
    r <- readRDS(file)
    stopifnot(identical(r$config_hash, config_hash))
  } else {
    set.seed(SEED + 1000L + b)
    counts <- tabulate(sample.int(length(hh), length(hh), replace = TRUE), nbins = length(hh))
    mult <- counts[hhindex]
    keep <- mult > 0
    z <- dat[keep, ]
    w <- z$w10xwgt * mult[keep]
    w <- w * sum(mult) / sum(w)
    fitted <- fit_set(z, w, p$grid, specs = c("simple", "additive"))
    r <- list(config_hash = config_hash, predictions = cbind(replication = b, fitted$predictions),
              diagnostics = cbind(replication = b, fitted$diagnostics))
    saveRDS(r, file)
  }
  bootpred[[b]] <- r$predictions
  bootdiag[[b]] <- r$diagnostics
  if (b %% 10L == 0L) cat("Bootstrap", b, "/", N_BOOT, "\n")
}
bootpred <- do.call(rbind, bootpred)
bootdiag <- do.call(rbind, bootdiag)
write_table(bootdiag, "bootstrap_diagnostics", out_main)

# Percentile intervals from numerically acceptable replicates (at least 80% required).
intervals <- list()
for (spec in c("simple", "additive")) for (model in c("Poisson", "NB2", "Hurdle NB2"))
  for (s in as.character(p$grid$stratum)) for (target in c("p", "m_plus", "total_mean", "recurrent_given_positive")) {
    z <- bootpred[bootpred$specification == spec & bootpred$model == model & as.character(bootpred$stratum) == s, ]
    v <- z[[target]][z$diagnostic_ok & is.finite(z[[target]])]
    enough <- length(v) >= ceiling(0.8 * N_BOOT)
    intervals[[length(intervals) + 1L]] <- data.frame(
      specification = spec, model = model, stratum = s, target = target, attempted = N_BOOT, available = length(v),
      interval_available = enough, lower = if (enough) quantile(v, 0.025) else NA_real_,
      upper = if (enough) quantile(v, 0.975) else NA_real_)
  }
write_table(do.call(rbind, intervals), "bootstrap_intervals", out_main)

# Proportional change in stratum variance (simple to MAIHDA), on each component's own latent scale.
pcvs <- list()
for (weighting in c("survey", "unweighted")) {
  r <- readRDS(file.path(private_dir, paste0("main_", weighting, ".rds")))
  for (comp in c("poisson", "nb2", "occurrence", "positive")) {
    simple <- r$diagnostics[r$diagnostics$component == comp & r$diagnostics$specification == "simple", ]
    add <- r$diagnostics[r$diagnostics$component == comp & r$diagnostics$specification == "additive", ]
    values <- numeric()
    if (weighting == "survey") for (b in seq_len(N_BOOT)) {
      s <- bootdiag[bootdiag$replication == b & bootdiag$component == comp & bootdiag$specification == "simple", ]
      a <- bootdiag[bootdiag$replication == b & bootdiag$component == comp & bootdiag$specification == "additive", ]
      if (s$good && a$good && s$random_variance > 1e-08) values <- c(values, 1 - a$random_variance / s$random_variance)
    }
    enough <- length(values) >= 0.8 * N_BOOT
    pcvs[[paste(weighting, comp)]] <- data.frame(
      weighting = weighting, component = comp, simple_variance = simple$random_variance,
      additive_variance = add$random_variance,
      pcv = if (simple$good && add$good && simple$random_variance > 1e-08) 1 - add$random_variance / simple$random_variance else NA_real_,
      bootstrap_available = length(values), lower = if (enough) quantile(values, 0.025) else NA_real_,
      upper = if (enough) quantile(values, 0.975) else NA_real_,
      scale = if (comp == "occurrence") "Latent logit occurrence" else "Log parent count mean; not observed-count VPC")
  }
}
write_table(do.call(rbind, pcvs), "component_pcv", out_main)

# ---- Summary tables ----
pr <- read_out(out_main, "predictions_survey")
uw <- read_out(out_main, "predictions_unweighted")
rows <- list()
for (target in c("p", "m_plus", "total_mean", "recurrent_given_positive"))
  for (pair in list(c("Poisson", "NB2"), c("NB2", "Hurdle NB2"), c("Poisson", "Hurdle NB2"))) {
    a <- pr[pr$specification == "additive" & pr$model == pair[1], ]
    b <- pr[pr$specification == "additive" & pr$model == pair[2], ]
    stopifnot(identical(a$stratum, b$stratum))
    rows[[length(rows) + 1]] <- data.frame(target = target, first = pair[1], second = pair[2],
                                           spearman = cor(a[[target]], b[[target]], method = "spearman"),
                                           note = "Agreement between model rankings; neither is a known truth")
  }
write_table(do.call(rbind, rows), "stratum_rank_agreement", out_main)

write_table(do.call(rbind, lapply(c("Poisson", "NB2", "Hurdle NB2"), function(model) {
  a <- pr[pr$specification == "additive" & pr$model == model, ]
  b <- uw[uw$specification == "additive" & uw$model == model, ]
  data.frame(model = model, occurrence_rank_correlation = cor(a$p, b$p, method = "spearman"),
             positive_rank_correlation = cor(a$m_plus, b$m_plus, method = "spearman"),
             max_absolute_occurrence_change = max(abs(a$p - b$p)),
             max_relative_positive_mean_change = max(abs(a$m_plus / b$m_plus - 1)))
})), "weight_sensitivity_summary", out_main)

s <- read_out(out_main, "sensitivity_predictions")
di <- read_out(out_main, "sensitivity_diagnostics")
write_table(do.call(rbind, lapply(unique(s$sensitivity), function(name) {
  a <- s[s$sensitivity == name, ]
  z <- di[di$sensitivity == name, ]
  data.frame(sensitivity = name, n = a$n[1], fallers = a$positive[1],
             occurrence_residual_variance = z$random_variance[z$component == "occurrence"],
             positive_residual_variance = z$random_variance[z$component == "positive"],
             positive_shape = z$dispersion[z$component == "positive"],
             all_components_numerically_acceptable = all(z$good))
})), "sensitivity_summary", out_main)
cat("03 complete\n")

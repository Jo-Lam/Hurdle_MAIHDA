# 07 Occurrence, frequency among fallers and overall mean by sex, age, education and wealth.
#   Marginal: weighted average of a category's own stratum predictions (comparable with observed values).
#   Standardised: each category applied to the weighted distribution of the other three characteristics.
source("R/setup.R")
p <- readRDS(file.path(private_dir, "prepared.rds"))
f <- readRDS(file.path(private_dir, "fixed_only_survey.rds"))
m <- readRDS(file.path(private_dir, "main_survey.rds"))
dims <- c("sex", "age_group", "education", "wealth_group")
w <- p$strata$sum_weight
key <- function(g) as.character(interaction(g[dims], sep = " | ", drop = FALSE))
summarise <- function(pp, mu, ww) {
  data.frame(p = weighted.mean(pp, ww), m_plus = weighted.mean(mu, ww) / weighted.mean(pp, ww),
             total_mean = weighted.mean(mu, ww))
}

rows <- list()
for (model in c("Poisson", "NB2", "Hurdle NB2")) for (structure in c("Fixed-only", "MAIHDA")) {
  pr <- if (structure == "Fixed-only") f$predictions[f$predictions$model == model, ]
        else m$predictions[m$predictions$specification == "additive" & m$predictions$model == model, ]
  stopifnot(identical(key(pr), key(p$grid)))
  for (v in dims) for (level in levels(p$grid[[v]])) {
    g <- p$grid
    g[[v]] <- factor(level, levels = levels(g[[v]]))
    i <- match(key(g), key(pr))
    rows[[length(rows) + 1L]] <- cbind(model = model, structure = structure, type = "Standardised", variable = v,
                                       category = level, summarise(pr$p[i], pr$total_mean[i], w))
    own <- p$grid[[v]] == level
    rows[[length(rows) + 1L]] <- cbind(model = model, structure = structure, type = "Marginal", variable = v,
                                       category = level, summarise(pr$p[own], pr$total_mean[own], w[own]))
  }
}
d <- p$data
for (v in dims) for (level in levels(p$grid[[v]])) {
  z <- d[d[[v]] == level, ]
  rows[[length(rows) + 1L]] <- cbind(model = "Observed", structure = "Weighted sample", type = "Marginal", variable = v,
                                     category = level, summarise(z$positive, z$y, z$w10xwgt))
}
write_table(do.call(rbind, rows), "category_components_all_models", out_contrasts)

# Standardised sex and age components for NB2 and hurdle MAIHDA across the sensitivity analyses,
# using the primary sample's weighted stratum distribution and each counterpart stratum's prediction.
st <- read_out(out_main, "stratum_information")
sk_w <- st$sum_weight
key2 <- function(x) do.call(paste, c(x[dims], sep = " | "))
sets <- list(Primary = read_out(out_main, "predictions_survey"), Unweighted = read_out(out_main, "predictions_unweighted"))
sens <- read_out(out_main, "sensitivity_predictions")
labels <- c(no_counts_above20 = "Excluding counts above 20", known_w9_interval = "Known recall interval (3.5 years)",
            no_imputed_wealth_components = "Excluding imputed wealth")
for (s in names(labels)) sets[[labels[[s]]]] <- sens[sens$sensitivity == s, ]
rows <- list()
for (a in names(sets)) for (model in c("NB2", "Hurdle NB2")) {
  pr <- sets[[a]]
  pr <- pr[pr$specification == "additive" & pr$model == model, ]
  pk <- key2(pr)
  for (v in c("sex", "age_group")) for (level in unique(st[[v]])) {
    g <- st
    g[[v]] <- level
    i <- match(key2(g), pk)
    stopifnot(!anyNA(i))
    pp <- weighted.mean(pr$p[i], sk_w)
    mu <- weighted.mean(pr$total_mean[i], sk_w)
    rows[[length(rows) + 1L]] <- data.frame(analysis = a, model = model, variable = v, category = level,
                                            p = pp, m_plus = mu / pp, total_mean = mu)
  }
}
write_table(do.call(rbind, rows), "sensitivity_category_components", out_contrasts)
cat("07 complete\n")

# 09 Figures: main-text Figure 4 and Supplementary Figures S1 and S2.
source("R/setup.R")
library(ggplot2)
library(patchwork)

cols <- c(Observed = "#3d3d3a", `NB2 MAIHDA` = "#eb6834", `Hurdle MAIHDA` = "#2a78d6")
shapes <- c(Observed = 16, `NB2 MAIHDA` = 17, `Hurdle MAIHDA` = 15)
theme_fig <- theme_minimal(base_size = 9) +
  theme(panel.grid.minor = element_blank(), panel.grid.major = element_line(colour = "#e4e3dc", linewidth = 0.3),
        legend.position = "bottom", legend.title = element_blank(),
        strip.text = element_text(face = "bold", hjust = 0), plot.title = element_text(face = "bold", size = 10))
# Curves joining combinations of occurrence and frequency with the same overall mean.
iso <- function(means, x) do.call(rbind, lapply(means, function(m) data.frame(mean = m, p = x, m_plus = m / x)))
short_education <- c(`No qualifications` = "None", `Other qualifications` = "Other", `Degree/equivalent` = "Degree")

# ---- Figure 4 ----
# Panel A: weighted averages of MAIHDA stratum predictions within each category, against observed values.
a <- read_out(out_contrasts, "category_components_all_models")
a <- a[a$model == "Observed" | (a$structure == "MAIHDA" & a$type == "Marginal" & a$model %in% c("NB2", "Hurdle NB2")), ]
a$source <- factor(ifelse(a$model == "Observed", "Observed", paste(sub("Hurdle NB2", "Hurdle", a$model), "MAIHDA")),
                   levels = names(cols))
stopifnot(!anyNA(a$source))
a$variable <- factor(c(sex = "Sex", age_group = "Age group", education = "Education", wealth_group = "Wealth tercile")[a$variable],
                     levels = c("Sex", "Age group", "Education", "Wealth tercile"))
order_levels <- c("Male", "Female", "60-69", "70-79", "80+", names(short_education), "Lower", "Middle", "Higher")
a <- a[order(a$variable, a$source, match(a$category, order_levels)), ]
a$label <- c(Male = "Men", Female = "Women", `60-69` = "60-69", `70-79` = "70-79", `80+` = "80+", short_education,
             Lower = "Lower", Middle = "Middle", Higher = "Higher")[a$category]
isoA <- iso(c(0.5, 0.75, 1, 1.5), seq(0.15, 0.45, length.out = 200))
isoA <- isoA[isoA$m_plus >= 1.8 & isoA$m_plus <= 5.5, ]
pa <- ggplot(a, aes(p, m_plus)) +
  geom_line(data = isoA, aes(group = mean), colour = "#b5b4ab", linetype = "dotted", linewidth = 0.4) +
  geom_path(aes(colour = source, group = source), linewidth = 0.5) +
  geom_point(aes(colour = source, shape = source), size = 2.2) +
  geom_text(data = a[a$source == "Observed", ], aes(label = label), size = 2.4, colour = "#3d3d3a",
            hjust = 0, nudge_x = 0.008, nudge_y = 0.18) +
  facet_wrap(~variable, nrow = 1) + scale_colour_manual(values = cols) + scale_shape_manual(values = shapes) +
  scale_x_continuous(labels = function(x) paste0(round(100 * x), "%"), limits = c(0.18, 0.42)) +
  scale_y_continuous(limits = c(1.8, 5.5)) +
  labs(title = "A. Characteristics defining the strata", x = "Probability of any fall", y = "Mean falls among fallers") +
  theme_fig

# Panel B: all 54 strata, arrows from NB2 MAIHDA to hurdle MAIHDA predictions.
s <- read_out(out_contrasts, "stratum_contrasts")
w <- merge(s[s$model == "NB2", c("stratum", "n_positive", "p_maihda", "m_plus_maihda")],
           s[s$model == "Hurdle NB2", c("stratum", "p_maihda", "m_plus_maihda")], by = "stratum", suffixes = c("_nb2", "_hurdle"))
pts <- rbind(
  data.frame(source = "NB2 MAIHDA", p = w$p_maihda_nb2, m_plus = w$m_plus_maihda_nb2, no_fallers = w$n_positive == 0),
  data.frame(source = "Hurdle MAIHDA", p = w$p_maihda_hurdle, m_plus = w$m_plus_maihda_hurdle, no_fallers = w$n_positive == 0))
pts$source <- factor(pts$source, levels = names(cols))
isoB <- iso(c(0.25, 0.5, 1, 2), seq(0.1, 0.5, length.out = 300))
isoB <- isoB[isoB$m_plus >= 1.3 & isoB$m_plus <= 14, ]
iso_labels <- do.call(rbind, lapply(c(0.25, 0.5, 1, 2), function(m) {
  x <- min(0.49, m / 1.45)
  data.frame(p = x, m_plus = m / x, lab = paste("Overall mean", m))
}))
pb <- ggplot() +
  geom_line(data = isoB, aes(p, m_plus, group = mean), colour = "#b5b4ab", linetype = "dotted", linewidth = 0.4) +
  geom_text(data = iso_labels, aes(p, m_plus, label = lab), size = 2.2, colour = "#8a897f", hjust = 1, vjust = -0.4) +
  geom_segment(data = w, aes(x = p_maihda_nb2, y = m_plus_maihda_nb2, xend = p_maihda_hurdle, yend = m_plus_maihda_hurdle),
               colour = "#b5b4ab", linewidth = 0.3, arrow = arrow(length = unit(1.3, "mm"), type = "closed")) +
  geom_point(data = pts[!pts$no_fallers, ], aes(p, m_plus, colour = source, shape = source), size = 1.8) +
  geom_point(data = pts[pts$no_fallers, ], aes(p, m_plus, colour = source), shape = 1, size = 2.6, stroke = 0.7) +
  scale_colour_manual(values = cols, drop = FALSE) + scale_shape_manual(values = shapes, drop = FALSE) +
  scale_x_continuous(labels = function(x) paste0(round(100 * x), "%"), limits = c(0.1, 0.5)) +
  scale_y_log10(breaks = c(1.5, 2, 3, 5, 8, 12), limits = c(1.3, 14)) +
  labs(title = "B. All 54 strata: arrows run from NB2 to hurdle MAIHDA predictions",
       x = "Probability of any fall", y = "Mean falls among fallers (log scale)") +
  theme_fig + theme(legend.position = "none")
fig4 <- pa / pb + plot_layout(heights = c(1, 1.35))
ggsave(file.path(out_contrasts, "figure4_components.png"), fig4, width = 7, height = 7.2, dpi = 300, bg = "white")
ggsave(file.path(out_contrasts, "figure4_components.pdf"), fig4, width = 7, height = 7.2, bg = "white")

# ---- Supplementary Figure S1: hurdle MAIHDA predictions for all strata with bootstrap intervals ----
pr <- read_out(out_main, "predictions_survey")
pr <- pr[pr$specification == "additive" & pr$model == "Hurdle NB2", ]
bi <- read_out(out_main, "bootstrap_intervals")
bi <- bi[bi$specification == "additive" & bi$model == "Hurdle NB2", ]
fx <- read_out(out_contrasts, "fixed_only_predictions")
fx <- fx[fx$model == "Hurdle NB2", ]
st <- read_out(out_main, "stratum_information")
short <- function(d) paste(ifelse(d$sex == "Male", "M", "F"), d$age_group, short_education[d$education], d$wealth_group)
targets <- c(total_mean = "Overall mean falls", p = "Probability of any fall", m_plus = "Mean falls among fallers")
rows <- do.call(rbind, lapply(names(targets), function(t) {
  b <- bi[bi$target == t, ]
  data.frame(label = short(pr), target = targets[[t]], estimate = pr[[t]],
             lower = b$lower[match(pr$stratum, b$stratum)], upper = b$upper[match(pr$stratum, b$stratum)],
             additive = fx[[t]][match(pr$stratum, fx$stratum)], fallers = st$n_positive[match(pr$stratum, st$stratum)])
}))
rows$label <- factor(rows$label, levels = short(pr[order(pr$total_mean), ]))
rows$target <- factor(rows$target, levels = targets)
rows$no_fallers <- rows$fallers == 0
hide <- rows$no_fallers & rows$target != "Probability of any fall"  # no interval where frequency is borrowed
rows$lower[hide] <- NA
rows$upper[hide] <- NA
s1 <- ggplot(rows, aes(y = label)) +
  geom_errorbar(aes(xmin = lower, xmax = upper), orientation = "y", width = 0, colour = "#86b6ef", linewidth = 0.5, na.rm = TRUE) +
  geom_point(aes(x = additive), shape = 124, size = 2.2, colour = "#8a897f") +
  geom_point(aes(x = estimate, shape = no_fallers), colour = "#2a78d6", size = 1.5, fill = "white") +
  scale_shape_manual(values = c(`FALSE` = 16, `TRUE` = 21), guide = "none") +
  facet_wrap(~target, nrow = 1, scales = "free_x") + scale_x_log10() +
  labs(x = "Prediction (log scale)", y = NULL) + theme_minimal(base_size = 8) +
  theme(panel.grid.minor = element_blank(), panel.grid.major.y = element_blank(),
        panel.grid.major.x = element_line(colour = "#e4e3dc", linewidth = 0.3),
        strip.text = element_text(face = "bold", hjust = 0), axis.text.y = element_text(size = 6))
ggsave(file.path(out_contrasts, "figureS1_caterpillar.png"), s1, width = 7, height = 8.5, dpi = 300, bg = "white")
ggsave(file.path(out_contrasts, "figureS1_caterpillar.pdf"), s1, width = 7, height = 8.5, bg = "white")

# ---- Supplementary Figure S2: post hoc examples (three largest upward, largest downward frequency departure) ----
h <- s[s$model == "Hurdle NB2", ]
sel <- h[c(head(order(-h$m_plus_log_interaction), 3), which.min(h$m_plus_log_interaction)), ]
sel$example <- LETTERS[1:4]
sel$label <- sprintf("%s. %s %s; %s\n%s wealth; %d fallers", sel$example, ifelse(sel$sex == "Male", "Men", "Women"),
                     sel$age_group, tolower(sel$education), sel$wealth_group, sel$n_positive)
write_table(sel[, c("example", "stratum", "n", "n_positive")], "candidate_strata", private_dir)  # small cells: local only
ci <- read_out(out_contrasts, "hurdle_contrast_intervals")
fc <- ci[ci$stratum %in% sel$stratum & ci$metric %in% c("p_log_interaction", "m_plus_log_interaction"), ]
fc$label <- factor(sel$label[match(fc$stratum, sel$stratum)], levels = rev(sel$label))
fc$component <- ifelse(fc$metric == "p_log_interaction", "Occurrence probability", "Mean count among fallers")
s2 <- ggplot(fc, aes(exp(estimate), label)) +
  geom_vline(xintercept = 1, linetype = 2, colour = "grey50") +
  geom_errorbar(aes(xmin = exp(lower), xmax = exp(upper)), orientation = "y", width = 0.12) +
  geom_point(size = 2.5, colour = "#2a78d6") +
  facet_wrap(~component, nrow = 1) + scale_x_log10() +
  labs(x = "Ratio with versus without the fitted stratum effect (log scale)", y = NULL,
       caption = "Post hoc examples from 54 strata; 95% pointwise household-bootstrap intervals. None passes the simultaneous screen.") +
  theme_minimal(base_size = 11)
ggsave(file.path(out_contrasts, "figureS2_examples.png"), s2, width = 12, height = 6, dpi = 180, bg = "white")
ggsave(file.path(out_contrasts, "figureS2_examples.pdf"), s2, width = 12, height = 6, bg = "white")
cat("09 complete\n")

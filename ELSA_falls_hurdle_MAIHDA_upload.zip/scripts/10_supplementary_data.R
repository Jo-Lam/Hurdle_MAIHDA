# 10 Supplementary data D9-D11 from aggregate outputs, with small cells suppressed.
# Disclosure rules:
#  1. Unweighted counts (participants, households, fallers, participants with two or more falls) below 10 are shown as "<10".
#  2. Weighted observed occurrence, overall mean and effective sample size are suppressed where participants < 10;
#     the weighted observed mean among fallers is suppressed where fallers < 10.
#  3. No maxima, tail counts or other statistics describing individual reports are released.
#  4. Model predictions are released for all strata; frequency intervals are omitted for a stratum without fallers.
source("R/setup.R")
wr <- function(x, f) utils::write.csv(x, file.path(out_supp, paste0(f, ".csv")), row.names = FALSE, na = "")
threshold <- 10L
supp_count <- function(x) ifelse(x < threshold, "<10", format(x, scientific = FALSE, trim = TRUE))
dims <- c("sex", "age_group", "education", "wealth_group")

# ---- D9: strata and weighted observed components ----
st <- read_out(out_main, "stratum_information")
d9 <- data.frame(
  stratum = st$stratum, st[dims],
  participants = supp_count(st$n), households = supp_count(st$n_households), fallers = supp_count(st$n_positive),
  participants_two_or_more_falls = supp_count(st$n_recurrent),
  effective_sample_size = ifelse(st$n < threshold, NA, round(st$effective_n)),
  weighted_observed_occurrence = ifelse(st$n < threshold, NA, round(st$weighted_p, 4)),
  weighted_observed_mean_among_fallers = ifelse(st$n_positive < threshold, NA, round(st$weighted_positive_mean, 3)),
  weighted_observed_overall_mean = ifelse(st$n < threshold, NA, round(st$weighted_mean, 3)), stringsAsFactors = FALSE)
stopifnot(nrow(d9) == 54)
wr(d9, "D9_elsa_strata")

# ---- D10: predictions from all six models ----
mai <- read_out(out_main, "predictions_survey")
mai <- mai[mai$specification == "additive", ]
mai$structure <- "MAIHDA"
fix <- read_out(out_contrasts, "fixed_only_predictions")
fix$structure <- "Additive only"
cols <- c("stratum", dims, "model", "structure", "p", "m_plus", "total_mean", "recurrent_given_positive")
pred <- rbind(mai[, cols], fix[, cols])
bi <- read_out(out_main, "bootstrap_intervals")
bi <- bi[bi$specification == "additive", ]
no_fallers <- st$n_positive[match(pred$stratum, st$stratum)] == 0
for (t in c("p", "m_plus", "total_mean", "recurrent_given_positive")) {
  b <- bi[bi$target == t, ]
  k <- match(paste(pred$model, pred$stratum), paste(b$model, b$stratum))
  lo <- ifelse(pred$structure == "MAIHDA", b$lower[k], NA)
  hi <- ifelse(pred$structure == "MAIHDA", b$upper[k], NA)
  if (t != "p") {
    lo[no_fallers] <- NA
    hi[no_fallers] <- NA
  }
  pred[[paste0(t, "_lower")]] <- lo
  pred[[paste0(t, "_upper")]] <- hi
}
rename <- c(p = "occurrence", m_plus = "mean_among_fallers", total_mean = "overall_mean",
            recurrent_given_positive = "two_or_more_given_any")
for (old in names(rename)) names(pred) <- sub(paste0("^", old, "(_lower|_upper)?$"), paste0(rename[[old]], "\\1"), names(pred))
num_cols <- vapply(pred, is.numeric, logical(1))
pred[num_cols] <- lapply(pred[num_cols], signif, 5)
pred <- pred[order(pred$model, pred$structure, pred$stratum), ]
stopifnot(nrow(pred) == 54 * 6)
wr(pred, "D10_elsa_predictions")

# ---- D11: validation, calibration, sensitivity and exploratory departures (long format) ----
long <- function(x, section, ids, note = "") {
  vals <- setdiff(names(x), ids)
  grp <- do.call(paste, c(lapply(ids, function(i) paste0(i, "=", x[[i]])), sep = "; "))
  do.call(rbind, lapply(vals, function(v) {
    data.frame(section = section, group = grp, quantity = v,
               value = as.character(if (is.numeric(x[[v]])) signif(x[[v]], 5) else x[[v]]), note = note, stringsAsFactors = FALSE)
  }))
}
cal <- read_out(out_main, "calibration")
pcv <- read_out(out_main, "component_pcv")
wt <- read_out(out_main, "wealth_thresholds")
d11 <- rbind(
  long(read_out(out_contrasts, "six_model_validation"), "Held-out scores, six models", c("structure", "model"), "Survey-weighted; five household folds"),
  long(read_out(out_main, "paired_cv_logscore_differences")[, 1:5], "Paired log-score differences between families (MAIHDA)", c("first", "second"), "Household resampling; folds held fixed"),
  long(read_out(out_contrasts, "paired_structure_scores"), "Paired log-score differences, MAIHDA minus additive only", "model", "Household resampling; folds held fixed"),
  long(read_out(out_contrasts, "tail_cv_scores"), "Held-out scores excluding counts above 20", c("structure", "model"), "Influence sensitivity; changes the estimand"),
  long(read_out(out_contrasts, "tail_cv_paired_scores")[, 1:4], "Paired log-score differences, sensitivity", "comparison", "Household resampling; folds held fixed"),
  long(cal[cal$weighting == "survey", c("model", "event", "type", "observed", "predicted")], "Calibration", c("model", "event", "type"), "Survey-weighted MAIHDA fits"),
  long(read_out(out_main, "stratum_rank_agreement")[, 1:4], "Spearman rank agreement between model predictions", c("target", "first", "second"), "MAIHDA predictions; 54 strata"),
  long(read_out(out_contrasts, "category_components_all_models"), "Occurrence and frequency by characteristic", c("model", "structure", "type", "variable", "category"),
       "Marginal: weighted average within category; standardised: other characteristics held at sample distribution"),
  long(read_out(out_contrasts, "sensitivity_category_components"), "Standardised components across sensitivity analyses", c("analysis", "model", "variable", "category"), "MAIHDA predictions"),
  long(read_out(out_main, "sensitivity_summary"), "Sensitivity analyses: sample and hurdle variances", "sensitivity", "Counts are unweighted; all exceed 10"),
  long(pcv[pcv$weighting == "survey", c("component", "scale", "simple_variance", "additive_variance", "pcv", "lower", "upper")],
       "Stratum variances and PCV", c("component", "scale"), "additive_variance is the MAIHDA (main effects plus stratum) variance"),
  long(read_out(out_contrasts, "hurdle_contrast_intervals")[, c("stratum", "metric", "estimate", "lower", "upper", "simultaneous_lower",
                                                                 "simultaneous_upper", "pointwise_excludes_zero", "simultaneous_excludes_zero")],
       "Exploratory stratum departures, hurdle MAIHDA (log ratios)", c("stratum", "metric"),
       "interaction: versus same model with stratum effect zero; model_difference: versus refitted additive model. Exploratory"),
  long(read_out(out_contrasts, "direction_stability"), "Direction of occurrence and frequency departures", "stratum", "Bootstrap stability summaries, not probabilities"),
  long(data.frame(tertile_cut = c("lower", "upper"), wealth_gbp = wt$wealth_cut), "Wealth tertile cut-points", "tertile_cut",
       "Benefit-unit net non-pension wealth; weighted among eligible core members aged 60+"))
stopifnot(!any(d11$quantity %in% c("n_above20", "maximum", "fraction_weighted_events_above20", "n_positive", "n_recurrent")))
wr(d11, "D11_elsa_validation")
cat("10 complete: suppressed participant cells", sum(d9$participants == "<10"), "; suppressed faller cells", sum(d9$fallers == "<10"), "\n")

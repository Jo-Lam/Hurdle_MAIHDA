# Occurrence and frequency of falls across intersectional strata: ELSA wave 10

Analysis code for the empirical illustration in *Estimating who is affected and how often with MAIHDA for rare health outcomes* (Lam, Koay and Cortina-Borja). The simulation study is in a separate repository: <https://github.com/Jo-Lam/Hurdle_MAIHDA>.

The code compares Poisson, negative-binomial (NB2) and hurdle NB2 models of the number of self-reported falls among people aged 60 or over in wave 10 of the English Longitudinal Study of Ageing (ELSA). For each of 54 strata defined by sex, age group, education and wealth tertile, it estimates:

- **occurrence**: the probability of any fall;
- **frequency**: the mean number of falls among fallers, including the first;
- **overall mean**: occurrence × frequency.

Each family is fitted as an additive model (main effects only) and as a MAIHDA model (main effects plus a stratum random intercept). This separates the effect of the count distribution from that of stratum random effects.

**This repository contains no ELSA data.**

## Data

ELSA data are available from the UK Data Service under an End User Licence (study number 5050). Download the Stata version of the ELSA archive and put the ZIP file in `data/`, or set the environment variable `ELSA_DATA_DIR` to the folder containing it. The code reads four files from the ZIP without unpacking the whole archive:

| File in the archive | Variables used |
|---|---|
| `wave_10_elsa_data_eul_v4.dta` | identifiers, household, core membership, cohort, proxy and institution flags, age, sex, falls (`hefla`, `heflb`), cross-sectional weight (`w10xwgt`), interview date |
| `wave_10_ifs_derived_variables.dta` | highest qualification (`edqual`) |
| `wave_10_financial_derived_variables.dta` | benefit-unit net non-pension wealth and its derivation and imputation flags |
| `wave_9_elsa_data*.dta` | previous interview date and proxy status (recall-interval sensitivity analysis) |

Results were produced with the archive whose SHA-256 is recorded in `outputs/main/input_provenance.csv`. Other editions may give slightly different numbers.

## Requirements

R 4.6.0 with glmmTMB 1.1.14, haven, digest, tidyselect, ggplot2 and patchwork. Session information is written to `outputs/main/session_info.txt`.

## Running

From the repository root:

```
Rscript run_all.R
```

A full run takes about 10 minutes on a laptop, most of it in the two household bootstraps. Bootstrap replicates are checkpointed in `private/`, so an interrupted run resumes where it stopped. A checkpoint created under different code or settings stops the run rather than being reused; delete the relevant `private/bootstrap_*` folder to start afresh.

| Script | Purpose |
|---|---|
| `01_prepare_and_fit.R` | Sample construction, strata, audit tables; primary fits (survey-weighted and unweighted) |
| `02_sensitivity_and_validation.R` | Sensitivity analyses; profile of the positive-count shape; five-fold household-held-out log and Brier scores; calibration |
| `03_bootstrap_and_summaries.R` | 200 household bootstrap refits; prediction intervals; proportional change in variance; rank agreement and summary tables |
| `04_additive_vs_maihda.R` | Additive-only models; stratum departures; paired held-out comparison of MAIHDA and additive models |
| `05_contrast_bootstrap.R` | Paired bootstrap of hurdle stratum departures; pointwise intervals, approximate simultaneous screen, direction stability |
| `06_verify.R` | Numerical checks (compression, normalisation of predicted distributions, random-effect identity, bootstrap agreement) |
| `07_category_components.R` | Occurrence and frequency by sex, age, education and wealth, including across sensitivity analyses |
| `08_tail_cross_validation.R` | Held-out comparison excluding reports of more than 20 falls |
| `09_figures.R` | Figure 4 and Supplementary Figures S1 and S2 |
| `10_supplementary_data.R` | Supplementary data D9–D11 with small cells suppressed |

Shared functions are in `R/falls_functions.R` (preparation, fitting, predictions and scoring) and `R/contrast_functions.R` (additive-only models and stratum departures).

## Analysis decisions

- **Sample:** core members aged 60 or over in private households, interviewed in person (falls were not asked of proxies), with a positive cross-sectional weight and complete information on falls, sex, education and wealth.
- **Outcome:** zero only when a participant explicitly reported no fall and the count question was skipped by routing; otherwise the reported count (1–400). Refused, unknown and out-of-scope responses are missing.
- **Recall period:** counts cover the period since the last interview, or the last two years for new participants. Estimates are not annual rates.
- **Weights:** survey weights are scaled to mean one and used as observation weights. This is a pseudo-likelihood analysis; the household bootstrap does not reproduce the survey's strata and primary sampling units.
- **Predictions:** every model's occurrence, frequency and overall mean are derived from its own fitted distribution. For the zero-truncated NB2 component, the parent mean is not the mean among fallers.

## Outputs and disclosure

Everything in `outputs/` and `private/` is generated locally and excluded from version control by `.gitignore`:

- `private/` contains participant-level data, fitted models and held-out predictions. Never share it.
- `outputs/main` and `outputs/contrasts` contain aggregate tables, some with small cells. Review them before sharing.
- `outputs/supplementary_data` contains D9–D11. Unweighted counts below 10 are shown as `<10`, observed values based on fewer than 10 people are suppressed, and no maxima or tail counts are released. Independent disclosure review against the End User Licence is still recommended before publication.

## Citation

Please cite the article and the ELSA data:

> Banks, J., et al. English Longitudinal Study of Ageing: Waves 0–11. UK Data Service. SN: 5050.
>
> Steptoe, A., Breeze, E., Banks, J., & Nazroo, J. (2013). Cohort profile: The English Longitudinal Study of Ageing. *International Journal of Epidemiology*, 42(6), 1640–1648.

## Licence

The code is released under the MIT licence (see `LICENSE`). The licence covers the code only; ELSA data remain subject to the UK Data Service End User Licence.
